<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Edit User</h2>
        <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label>Name</label>
                <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Role</label>
                <select name="role" class="form-control" required>
                    <option value="beneficiary" <?php echo e($user->role == 'beneficiary' ? 'selected' : ''); ?>>Beneficiary</option>
                    <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                    <option value="store" <?php echo e($user->role == 'store' ? 'selected' : ''); ?>>Store</option>
                    <option value="charity" <?php echo e($user->role == 'charity' ? 'selected' : ''); ?>>Charity</option>
                </select>
            </div>
            <button class="btn btn-primary">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>