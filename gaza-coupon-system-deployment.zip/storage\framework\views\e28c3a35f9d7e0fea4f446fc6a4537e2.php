<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h4>Create New Request</h4>

        <form method="POST" action="<?php echo e(route('requests.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="type" class="form-label">Request Type</label>
                <select class="form-select" name="type" required>
                    <option value="Monthly">Monthly</option>
                    <option value="Emergency">Emergency</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="details" class="form-label">Details</label>
                <textarea class="form-control" name="details" rows="3" required></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Submit Request</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\beneficiary\requests\create.blade.php ENDPATH**/ ?>