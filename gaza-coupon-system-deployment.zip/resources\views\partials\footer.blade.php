<footer class="text-center text-muted py-3 mt-5">
    Gaza Coupon Management System - {{ date('Y') }} &copy;
</footer>
