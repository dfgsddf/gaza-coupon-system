

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Contact Messages</h2>
        <div class="d-flex gap-2">
            <button class="btn btn-outline-primary" onclick="refreshStats()">
                <i class="fa-solid fa-refresh"></i> Refresh Stats
            </button>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">Total Messages</h6>
                            <h3 class="mb-0" id="total-messages"><?php echo e($messages->total()); ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-envelope fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">Unread Messages</h6>
                            <h3 class="mb-0" id="unread-messages"><?php echo e($messages->where('status', 'unread')->count()); ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-eye-slash fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">Replied Messages</h6>
                            <h3 class="mb-0" id="replied-messages"><?php echo e($messages->where('status', 'replied')->count()); ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-reply fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h6 class="card-title">Recent (7 days)</h6>
                            <h3 class="mb-0" id="recent-messages"><?php echo e($messages->where('created_at', '>=', now()->subDays(7))->count()); ?></h3>
                        </div>
                        <div class="align-self-center">
                            <i class="fa-solid fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Messages Table -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">All Messages</h5>
                <div class="d-flex gap-2">
                    <select class="form-select form-select-sm" id="status-filter" style="width: auto;">
                        <option value="">All Status</option>
                        <option value="unread">Unread</option>
                        <option value="read">Read</option>
                        <option value="replied">Replied</option>
                        <option value="archived">Archived</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($message->status === 'unread' ? 'table-warning' : ''); ?>">
                            <td><?php echo e($message->id); ?></td>
                            <td>
                                <strong><?php echo e($message->name); ?></strong>
                                <?php if($message->status === 'unread'): ?>
                                    <span class="badge bg-danger ms-1">New</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="mailto:<?php echo e($message->email); ?>"><?php echo e($message->email); ?></a>
                            </td>
                            <td><?php echo e(Str::limit($message->subject, 50)); ?></td>
                            <td>
                                <?php switch($message->status):
                                    case ('unread'): ?>
                                        <span class="badge bg-warning">Unread</span>
                                        <?php break; ?>
                                    <?php case ('read'): ?>
                                        <span class="badge bg-info">Read</span>
                                        <?php break; ?>
                                    <?php case ('replied'): ?>
                                        <span class="badge bg-success">Replied</span>
                                        <?php break; ?>
                                    <?php case ('archived'): ?>
                                        <span class="badge bg-secondary">Archived</span>
                                        <?php break; ?>
                                    <?php default: ?>
                                        <span class="badge bg-secondary"><?php echo e(ucfirst($message->status)); ?></span>
                                <?php endswitch; ?>
                            </td>
                            <td><?php echo e($message->created_at->format('M d, Y H:i')); ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('admin.contact-messages.show', $message->id)); ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                    <?php if($message->status !== 'replied'): ?>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-success"
                                            onclick="markAsReplied(<?php echo e($message->id); ?>)">
                                        <i class="fa-solid fa-reply"></i>
                                    </button>
                                    <?php endif; ?>
                                    <button type="button" 
                                            class="btn btn-sm btn-outline-danger"
                                            onclick="deleteMessage(<?php echo e($message->id); ?>)">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="fa-solid fa-inbox fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No contact messages found</h5>
                                <p class="text-muted">Contact form submissions will appear here.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if($messages->hasPages()): ?>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($messages->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Toasts -->
<div class="position-fixed top-0 end-0 p-3" style="z-index: 9999">
    <div id="contact-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body" id="contact-toast-body"></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
function showContactToast(msg, type = 'success') {
    const toast = $('#contact-toast');
    toast.removeClass('text-bg-success text-bg-danger text-bg-info').addClass('text-bg-' + type);
    $('#contact-toast-body').text(msg);
    toast.toast('show');
}

function markAsReplied(messageId) {
    if (confirm('Mark this message as replied?')) {
        $.ajax({
            url: `/admin/contact-messages/${messageId}/replied`,
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content') },
            success: function(res) {
                showContactToast('Message marked as replied successfully', 'success');
                setTimeout(() => location.reload(), 1000);
            },
            error: function(xhr) {
                showContactToast(xhr.responseJSON?.message || 'Error updating message', 'danger');
            }
        });
    }
}

function deleteMessage(messageId) {
    if (confirm('Are you sure you want to delete this message? This action cannot be undone.')) {
        $.ajax({
            url: `/admin/contact-messages/${messageId}`,
            method: 'DELETE',
            headers: { 'X-CSRF-TOKEN': $('meta[name=csrf-token]').attr('content') },
            success: function(res) {
                showContactToast('Message deleted successfully', 'success');
                setTimeout(() => location.reload(), 1000);
            },
            error: function(xhr) {
                showContactToast(xhr.responseJSON?.message || 'Error deleting message', 'danger');
            }
        });
    }
}

function refreshStats() {
    $.ajax({
        url: "<?php echo e(route('admin.contact-messages.stats')); ?>",
        method: 'GET',
        success: function(res) {
            $('#total-messages').text(res.total_messages);
            $('#unread-messages').text(res.unread_messages);
            $('#replied-messages').text(res.messages_by_status.replied);
            $('#recent-messages').text(res.recent_messages);
            showContactToast('Statistics updated successfully', 'info');
        },
        error: function() {
            showContactToast('Error updating statistics', 'danger');
        }
    });
}

// Status filter
$('#status-filter').on('change', function() {
    const status = $(this).val();
    if (status) {
        window.location.href = "<?php echo e(route('admin.contact-messages.index')); ?>?status=" + status;
    } else {
        window.location.href = "<?php echo e(route('admin.contact-messages.index')); ?>";
    }
});

// Set current filter value
$(document).ready(function() {
    const urlParams = new URLSearchParams(window.location.search);
    const status = urlParams.get('status');
    if (status) {
        $('#status-filter').val(status);
    }
});
</script> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\admin\contact-messages\index.blade.php ENDPATH**/ ?>