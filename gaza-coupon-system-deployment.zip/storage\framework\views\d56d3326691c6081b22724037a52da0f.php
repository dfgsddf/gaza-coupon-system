<!-- resources/views/partials/navbar.blade.php -->
<nav class="navbar">
    <div class="logo">
        <a href="<?php echo e(url('/')); ?>">GAZA COUPON</a>
    </div>
    <ul class="nav-links">
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
        <li><a href="<?php echo e(url('/help')); ?>">Help & Support</a></li>
        <li><a href="<?php echo e(url('/store')); ?>">Store</a></li>
        <li><a href="<?php echo e(url('/beneficiary')); ?>">Beneficiary</a></li>
        <li><a href="<?php echo e(url('/charity')); ?>">Charity</a></li>
        <li><a href="<?php echo e(url('/admin')); ?>">Admin</a></li>
        <?php if(auth()->guard()->guest()): ?>
        <li><a href="<?php echo e(route('login.form')); ?>" class="btn btn-primary ms-2">Login</a></li>
        <?php endif; ?>
        <?php if(app()->environment('local', 'development')): ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">Force Login</a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="/force-login">Admin</a></li>
                    <li><a class="dropdown-item" href="/force-login-store">Store</a></li>
                    <li><a class="dropdown-item" href="/force-login-beneficiary">Beneficiary</a></li>
                    <li><a class="dropdown-item" href="/force-login-charity">Charity</a></li>
                </ul>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\partials\navbar.blade.php ENDPATH**/ ?>