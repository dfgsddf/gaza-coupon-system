<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h3>Coupon Details</h3>
        <div class="card p-4">
            <h4 class="text-primary">$<?php echo e($coupon->value); ?></h4>
            <p><strong>Store:</strong> <?php echo e($coupon->store_name); ?></p>
            <p><strong>Description:</strong> <?php echo e($coupon->description ?? 'N/A'); ?></p>
            <p><strong>Expires At:</strong> <?php echo e(\Carbon\Carbon::parse($coupon->expiry_date)->format('M d, Y')); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\coupons\show.blade.php ENDPATH**/ ?>