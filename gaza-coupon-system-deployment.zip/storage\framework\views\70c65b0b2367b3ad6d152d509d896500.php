<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4>Your Requests</h4>
            <a href="<?php echo e(route('requests.create')); ?>" class="btn btn-primary">New Request</a>
        </div>

        <div class="card">
            <div class="card-body">
                <?php if($requests->count()): ?>
                    <table class="table table-bordered">
                        <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Type</th>
                            <th>Details</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($request->id); ?></td>
                                <td><?php echo e(ucfirst($request->type)); ?></td>
                                <td><?php echo e($request->description ?? '-'); ?></td>
                                <td><?php echo e($request->created_at->format('M d, Y')); ?></td>
                                <td>
                                    <span class="badge
                                        <?php if($request->status == 'approved'): ?> bg-success
                                        <?php elseif($request->status == 'rejected'): ?> bg-danger
                                        <?php else: ?> bg-warning text-dark <?php endif; ?>">
                                        <?php echo e(ucfirst($request->status)); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-muted">You have no requests yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\beneficiary\requests\index.blade.php ENDPATH**/ ?>