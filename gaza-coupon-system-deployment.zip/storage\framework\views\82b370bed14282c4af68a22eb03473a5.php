<footer class="text-center text-muted py-3 mt-5">
    Gaza Coupon Management System - <?php echo e(date('Y')); ?> &copy;
</footer>
<?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\partials\footer.blade.php ENDPATH**/ ?>