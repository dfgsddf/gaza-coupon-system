<?php $__env->startSection('content'); ?>
    <main class="container py-5">
        <div class="row gy-4 align-items-start">
            <!-- Contact Form -->
            <div class="col-lg-6">
                <h4 class="fw-bold">Contact Us</h4>
                <p class="mb-4">Get in touch with us for any inquiries or support</p>
                
                <!-- Success/Error Messages -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fa-solid fa-check-circle me-2"></i>
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fa-solid fa-exclamation-triangle me-2"></i>
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="fa-solid fa-exclamation-triangle me-2"></i>
                        <strong>Please fix the following errors:</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('contact.submit')); ?>" method="POST" id="contact-form">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Name *</label>
                        <input type="text" 
                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="name" 
                               name="name" 
                               placeholder="Your full name"
                               value="<?php echo e(old('name')); ?>"
                               required />
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" 
                               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="email" 
                               name="email" 
                               placeholder="your.email@example.com"
                               value="<?php echo e(old('email')); ?>"
                               required />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-3">
                        <label for="subject" class="form-label">Subject *</label>
                        <select class="form-select <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="subject" 
                                name="subject" 
                                required>
                            <option value="" selected disabled>Choose a subject</option>
                            <option value="Technical Support" <?php echo e(old('subject') == 'Technical Support' ? 'selected' : ''); ?>>Technical Support</option>
                            <option value="Account Issue" <?php echo e(old('subject') == 'Account Issue' ? 'selected' : ''); ?>>Account Issue</option>
                            <option value="Store Inquiry" <?php echo e(old('subject') == 'Store Inquiry' ? 'selected' : ''); ?>>Store Inquiry</option>
                            <option value="Charity Support" <?php echo e(old('subject') == 'Charity Support' ? 'selected' : ''); ?>>Charity Support</option>
                            <option value="General Question" <?php echo e(old('subject') == 'General Question' ? 'selected' : ''); ?>>General Question</option>
                            <option value="Feedback" <?php echo e(old('subject') == 'Feedback' ? 'selected' : ''); ?>>Feedback</option>
                            <option value="Other" <?php echo e(old('subject') == 'Other' ? 'selected' : ''); ?>>Other</option>
                        </select>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="mb-3">
                        <label for="message" class="form-label">Message *</label>
                        <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="message" 
                                  name="message" 
                                  rows="5" 
                                  placeholder="Please describe your inquiry or issue in detail..."
                                  maxlength="5000"
                                  required><?php echo e(old('message')); ?></textarea>
                        <div class="form-text">
                            <span id="char-count">0</span> / 5000 characters
                        </div>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100" id="submit-btn">
                        <i class="fa-solid fa-paper-plane me-2"></i>
                        Send Message
                    </button>
                </form>
            </div>

            <!-- Contact Info -->
            <div class="col-lg-6">
                <h5 class="fw-bold">Contact Information</h5>
                <ul class="list-unstyled mt-4">
                    <li class="mb-3">
                        <i class="fa-solid fa-location-dot text-primary me-2"></i>
                        <strong>Address:</strong> 122 Gui, Gaza - Palestine
                    </li>
                    <li class="mb-3">
                        <i class="fa-solid fa-envelope text-primary me-2"></i>
                        <strong>Email:</strong> 
                        <a href="mailto:info@gazacoupon.com">info@gazacoupon.com</a>
                    </li>
                    <li class="mb-3">
                        <i class="fa-solid fa-phone text-primary me-2"></i>
                        <strong>Phone:</strong> 
                        <a href="tel:+970595700555">+970 59 5700 555</a>
                    </li>
                    <li class="mb-3">
                        <i class="fa-solid fa-clock text-primary me-2"></i>
                        <strong>Business Hours:</strong> Sunday - Thursday, 9:00 AM - 6:00 PM
                    </li>
                </ul>
                
                <div class="card mt-4">
                    <div class="card-body">
                        <h6 class="card-title">
                            <i class="fa-solid fa-info-circle text-info me-2"></i>
                            Response Time
                        </h6>
                        <p class="card-text mb-0">
                            We typically respond to inquiries within 24-48 hours during business days.
                        </p>
                    </div>
                </div>
                
                <div class="mt-4">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d217929.25881461377!2d34.22353897372741!3d31.41013997833182!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14fd844104b258a9%3A0xfddcb14b194be8e7!2sGaza%20Strip!5e0!3m2!1sen!2s!4v1751187039019!5m2!1sen!2s"
                            width="100%" 
                            height="300" 
                            style="border:0;" 
                            allowfullscreen="" 
                            loading="lazy" 
                            referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<script>
// Character counter for message textarea
document.getElementById('message').addEventListener('input', function() {
    const charCount = this.value.length;
    document.getElementById('char-count').textContent = charCount;
    
    // Change color when approaching limit
    const charCountElement = document.getElementById('char-count');
    if (charCount > 4500) {
        charCountElement.style.color = '#dc3545';
    } else if (charCount > 4000) {
        charCountElement.style.color = '#ffc107';
    } else {
        charCountElement.style.color = '#6c757d';
    }
});

// Form submission handling with CSRF token refresh
document.getElementById('contact-form').addEventListener('submit', function(e) {
    const submitBtn = document.getElementById('submit-btn');
    const originalText = submitBtn.innerHTML;
    
    // Disable button and show loading state
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-2"></i>Sending...';
    
    // Re-enable button after 10 seconds if there's an error
    setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
    }, 10000);
});

// Auto-dismiss alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Refresh CSRF token every 30 minutes to prevent expiration
    setInterval(function() {
        fetch('/csrf-token')
            .then(response => response.json())
            .then(data => {
                document.querySelector('input[name="_token"]').value = data.token;
            })
            .catch(error => {
                console.log('CSRF token refresh failed:', error);
            });
    }, 30 * 60 * 1000); // 30 minutes
});

// Handle 419 errors by refreshing the page
if (window.location.href.includes('419') || document.title.includes('419')) {
    setTimeout(() => {
        window.location.reload();
    }, 2000);
}
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views\contact.blade.php ENDPATH**/ ?>