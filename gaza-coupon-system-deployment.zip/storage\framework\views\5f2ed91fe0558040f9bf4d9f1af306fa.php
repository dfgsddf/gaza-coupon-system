<?php $__env->startSection('sidebar'); ?>
    <div class="p-4">
        <h5 class="mb-4">Gaza Coupon</h5>
        <a href="<?php echo e(route('charity.dashboard')); ?>" class="d-block text-white mb-3"><i class="fa-solid fa-gauge"></i> Dashboard</a>
        <a href="<?php echo e(route('charity.campaigns')); ?>" class="d-block text-white mb-3"><i class="fa-solid fa-compass"></i> Campaigns</a>
        <a href="<?php echo e(route('charity.requests')); ?>" class="d-block text-white mb-3"><i class="fa-solid fa-code-pull-request"></i> Requests</a>
        <a href="<?php echo e(route('charity.reports')); ?>" class="d-block text-white mb-3"><i class="fa-solid fa-book-open"></i> Reports</a>
        <a href="<?php echo e(route('charity.settings')); ?>" class="d-block text-white mb-3"><i class="fa-solid fa-gear"></i> Settings</a>
        <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout-form">
            <?php echo csrf_field(); ?>
            <button type="button" class="btn btn-link text-white text-start p-0" onclick="if(confirm('Are you sure?')){$('#logout-form').submit();}">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <!-- Main dashboard content here (copy from previous <?php $__env->startSection('content'); ?>) -->
        <?php echo $__env->make('charity._dashboard_content', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views/charity/dashboard.blade.php ENDPATH**/ ?>