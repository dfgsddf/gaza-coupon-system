<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="text-white mb-3">Charity Dashboard</h2>
            <p class="text-light">Welcome back, <?php echo e(Auth::user()->name); ?>! (Charity)</p>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card bg-primary text-white">
                <div class="card-body text-center">
                    <h5 class="card-title">Total Campaigns</h5>
                    <h3 class="mb-0" id="campaigns-count"><?php echo e($campaignsCount ?? 0); ?></h3>
                    <small>Click to refresh</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-success text-white">
                <div class="card-body text-center">
                    <h5 class="card-title">Active Campaigns</h5>
                    <h3 class="mb-0" id="active-campaigns-count"><?php echo e($activeCampaignsCount ?? 0); ?></h3>
                    <small>Click to refresh</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-info text-white">
                <div class="card-body text-center">
                    <h5 class="card-title">Total Donations</h5>
                    <h3 class="mb-0" id="total-donations">$<?php echo e(number_format($totalDonations ?? 0, 2)); ?></h3>
                    <small>Click to refresh</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card bg-warning text-white">
                <div class="card-body text-center">
                    <h5 class="card-title">Pending Requests</h5>
                    <h3 class="mb-0" id="pending-requests-count"><?php echo e($pendingRequests ?? 0); ?></h3>
                    <small>Click to refresh</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card bg-dark text-white">
                <div class="card-header">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 mb-2">
                            <a href="<?php echo e(route('charity.campaigns')); ?>" class="btn btn-outline-primary w-100">
                                <i class="fa-solid fa-plus me-2"></i>Create Campaign
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="<?php echo e(route('charity.requests')); ?>" class="btn btn-outline-success w-100">
                                <i class="fa-solid fa-eye me-2"></i>View Requests
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="<?php echo e(route('charity.reports')); ?>" class="btn btn-outline-info w-100">
                                <i class="fa-solid fa-chart-bar me-2"></i>Generate Report
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <button class="btn btn-outline-secondary w-100" onclick="refreshAll()">
                                <i class="fa-solid fa-sync-alt me-2"></i>Refresh All
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Dashboard Content -->
    <div class="row">
        <!-- Recent Campaigns -->
        <div class="col-md-6 mb-4">
            <div class="card bg-dark text-white">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Campaigns</h5>
                    <button class="btn btn-sm btn-outline-light" onclick="refreshCampaigns()">Refresh</button>
                </div>
                <div class="card-body">
                    <div id="recent-campaigns">
                        <?php if(isset($recentCampaigns) && $recentCampaigns->count() > 0): ?>
                            <?php $__currentLoopData = $recentCampaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex justify-content-between align-items-center mb-2 p-2 border-bottom">
                                    <div>
                                        <strong><?php echo e($campaign->title); ?></strong>
                                        <br>
                                        <small class="text-muted">Goal: $<?php echo e(number_format($campaign->goal, 2)); ?></small>
                                    </div>
                                    <span class="badge bg-<?php echo e($campaign->status === 'active' ? 'success' : 'secondary'); ?>">
                                        <?php echo e(ucfirst($campaign->status)); ?>

                                    </span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-muted">No campaigns found</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Donations -->
        <div class="col-md-6 mb-4">
            <div class="card bg-dark text-white">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Donations</h5>
                    <button class="btn btn-sm btn-outline-light" onclick="refreshDonations()">Refresh</button>
                </div>
                <div class="card-body">
                    <div id="recent-donations">
                        <?php if(isset($recentDonations) && $recentDonations->count() > 0): ?>
                            <?php $__currentLoopData = $recentDonations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex justify-content-between align-items-center mb-2 p-2 border-bottom">
                                    <div>
                                        <strong>$<?php echo e(number_format($donation->amount, 2)); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($donation->campaign->title ?? 'Unknown Campaign'); ?></small>
                                    </div>
                                    <small class="text-muted"><?php echo e($donation->created_at->diffForHumans()); ?></small>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-muted">No donations found</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Requests -->
    <div class="row">
        <div class="col-12">
            <div class="card bg-dark text-white">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Requests</h5>
                    <button class="btn btn-sm btn-outline-light" onclick="refreshRequests()">Refresh</button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-dark table-striped">
                            <thead>
                                <tr>
                                    <th>Beneficiary</th>
                                    <th>Request Type</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="recent-requests-tbody">
                                <?php if(isset($recentRequests) && $recentRequests->count() > 0): ?>
                                    <?php $__currentLoopData = $recentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($request->user->name ?? 'Unknown'); ?></td>
                                            <td><?php echo e($request->type ?? 'General'); ?></td>
                                            <td>$<?php echo e(number_format($request->amount ?? 0, 2)); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo e($request->status === 'approved' ? 'success' : ($request->status === 'rejected' ? 'danger' : 'warning')); ?>">
                                                    <?php echo e(ucfirst($request->status ?? 'pending')); ?>

                                                </span>
                                            </td>
                                            <td><?php echo e($request->created_at->format('M d, Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('charity.requests')); ?>" class="btn btn-sm btn-outline-primary">View</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center">No requests found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Toast for notifications -->
<div class="position-fixed top-0 end-0 p-3" style="z-index: 9999">
    <div id="charity-toast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body" id="charity-toast-body"></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>

<script>
function showCharityToast(message, type = 'success') {
    const toast = document.getElementById('charity-toast');
    const toastBody = document.getElementById('charity-toast-body');
    
    toast.className = `toast align-items-center text-bg-${type} border-0`;
    toastBody.textContent = message;
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
}

function refreshAll() {
    refreshStats();
    refreshCampaigns();
    refreshDonations();
    refreshRequests();
    showCharityToast('All data refreshed!');
}

function refreshStats() {
    fetch('<?php echo e(route("charity.dashboard.stats")); ?>')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('campaigns-count').textContent = data.campaign_stats.total;
                document.getElementById('active-campaigns-count').textContent = data.campaign_stats.active;
                document.getElementById('total-donations').textContent = '$' + parseFloat(data.donation_stats.total_amount).toFixed(2);
                document.getElementById('pending-requests-count').textContent = data.request_stats.pending;
            }
        })
        .catch(error => {
            console.error('Error refreshing stats:', error);
        });
}

function refreshCampaigns() {
    // In a real application, you would fetch recent campaigns from an API endpoint
    showCharityToast('Campaigns refreshed!');
}

function refreshDonations() {
    // In a real application, you would fetch recent donations from an API endpoint
    showCharityToast('Donations refreshed!');
}

function refreshRequests() {
    // In a real application, you would fetch recent requests from an API endpoint
    showCharityToast('Requests refreshed!');
}

// Auto-refresh every 30 seconds
setInterval(function() {
    refreshStats();
}, 30000);

// Make stats cards clickable for refresh
document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('click', function() {
        if (this.querySelector('small')) {
            refreshStats();
            showCharityToast('Statistics refreshed!');
        }
    });
});
</script> <?php /**PATH C:\laragon-lite\laragon\www\gaza-coupon-system\resources\views/charity/_dashboard_content.blade.php ENDPATH**/ ?>